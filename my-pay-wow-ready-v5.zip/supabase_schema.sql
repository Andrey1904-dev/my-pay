-- Моя зарплата — Supabase schema
-- Вставь целиком в Supabase → SQL Editor → Run.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  name text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  base_pay numeric not null default 2150,
  holiday_pay numeric not null default 4050,
  case_price numeric not null default 7,
  piece_percent numeric not null default 20,
  schedule_start date not null default current_date,
  monthly_goal numeric not null default 60000,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.shifts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  work_date date not null,
  cases integer not null default 0 check (cases >= 0),
  is_holiday boolean not null default false,
  base_pay numeric not null default 2150,
  piece_pay numeric not null default 0,
  total_pay numeric not null default 2150,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id,work_date)
);

-- Профиль и настройки создаются из браузера после signUp.
-- Email подтверждение в Supabase должно быть отключено, чтобы signUp сразу вернул session.

alter table public.profiles enable row level security;
alter table public.settings enable row level security;
alter table public.shifts enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
drop policy if exists "profiles_insert_own" on public.profiles;
drop policy if exists "profiles_update_own" on public.profiles;
drop policy if exists "profiles_delete_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select using (auth.uid()=id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid()=id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid()=id) with check (auth.uid()=id);
create policy "profiles_delete_own" on public.profiles for delete using (auth.uid()=id);

drop policy if exists "settings_select_own" on public.settings;
drop policy if exists "settings_insert_own" on public.settings;
drop policy if exists "settings_update_own" on public.settings;
drop policy if exists "settings_delete_own" on public.settings;
create policy "settings_select_own" on public.settings for select using (auth.uid()=user_id);
create policy "settings_insert_own" on public.settings for insert with check (auth.uid()=user_id);
create policy "settings_update_own" on public.settings for update using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "settings_delete_own" on public.settings for delete using (auth.uid()=user_id);

drop policy if exists "shifts_select_own" on public.shifts;
drop policy if exists "shifts_insert_own" on public.shifts;
drop policy if exists "shifts_update_own" on public.shifts;
drop policy if exists "shifts_delete_own" on public.shifts;
create policy "shifts_select_own" on public.shifts for select using (auth.uid()=user_id);
create policy "shifts_insert_own" on public.shifts for insert with check (auth.uid()=user_id);
create policy "shifts_update_own" on public.shifts for update using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "shifts_delete_own" on public.shifts for delete using (auth.uid()=user_id);

grant usage on schema public to authenticated;
grant select,insert,update,delete on public.profiles,public.settings,public.shifts to authenticated;
