// Supabase Edge Function skeleton for real background Web Push.
// Install a Web Push-compatible library in the function environment and set:
// VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT.
// Then call this function from a scheduled Supabase job/cron.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const { data: subscriptions, error } = await supabase
    .from("push_subscriptions")
    .select("id,user_id,endpoint,p256dh,auth");

  if (error) return new Response(JSON.stringify({error: error.message}), {status:500});

  // TODO: use a Web Push library to send each payload:
  // { title: "Моя зарплата", body: "Завтра смена в 09:00" }
  // Remove subscriptions that return HTTP 404/410.
  return new Response(JSON.stringify({
    ok:true,
    subscriptionsFound: subscriptions?.length ?? 0,
    note:"Connect a Web Push library and schedule this function."
  }), {headers:{"content-type":"application/json"}});
});
